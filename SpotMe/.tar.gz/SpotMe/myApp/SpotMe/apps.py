from django.apps import AppConfig


class SpotmeConfig(AppConfig):
    name = 'SpotMe'
